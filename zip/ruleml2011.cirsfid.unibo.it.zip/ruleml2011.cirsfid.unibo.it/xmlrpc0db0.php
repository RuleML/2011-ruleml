<?xml version="1.0" encoding="UTF-8"?><rsd version="1.0" xmlns="http://archipelago.phrasewise.com/rsd">
  <service>
    <engineName>WordPress</engineName>
    <engineLink>http://wordpress.org/</engineLink>
    <homePageLink>http://ruleml2011.cirsfid.unibo.it</homePageLink>
    <apis>
      <api name="WordPress" blogID="1" preferred="true" apiLink="http://ruleml2011.cirsfid.unibo.it/xmlrpc.php" />
      <api name="Movable Type" blogID="1" preferred="false" apiLink="http://ruleml2011.cirsfid.unibo.it/xmlrpc.php" />
      <api name="MetaWeblog" blogID="1" preferred="false" apiLink="http://ruleml2011.cirsfid.unibo.it/xmlrpc.php" />
      <api name="Blogger" blogID="1" preferred="false" apiLink="http://ruleml2011.cirsfid.unibo.it/xmlrpc.php" />
      <api name="Atom" blogID="" preferred="false" apiLink="http://ruleml2011.cirsfid.unibo.it/wp-app.php/service" />
    </apis>
  </service>
</rsd>
